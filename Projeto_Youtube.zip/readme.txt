PASSO A PASSO PARA INICIAR OS ARQUIVOS
------------------------------------------------------------------------
A) Base de Dados:
   - O arquivo `trending_by_time.csv` contém o histórico de vídeos em 
     alta no YouTube por país, categoria e data.

B) Dashboard (Tableau):
   - Clique no link para abrir o Dashboard: https://public.tableau.com/views/Projeto_Youtube_17864619061670/DashboardYouTubeTrending?:language=pt-BR&publish=yes&:sid=&:redirect=auth&:display_count=n&:origin=viz_share_link


C) Apresentação do Relatório:
   - Abra o arquivo em PDF referente à apresentação.

3. ESTRUTURA DOS ARQUIVOS DO PROJETO
------------------------------------------------------------------------
- readme.txt                                                              : Este arquivo de instruções.
- trending_by_time.csv                                                    : Base de dados.
- Projeto_YouTube.twb                                                     : Dashboard interativo do Tableau.
- Apresentação Relatório - Análise de Vídeos de Tendências no YouTube.pdf : Apresentação dos resultados.
========================================================================